# Stylized Desk Lamp - Blender Portfolio Study

## Files

- `stylized_desk_lamp.obj` and `stylized_desk_lamp.mtl`: editable low-poly mesh and material palette; import the OBJ into Blender.
- `build_in_blender.py`: optional Blender script that parses the OBJ, creates UV maps and procedural materials, adds a studio scene, and saves a native `.blend` file and render next to the source files.
- `preview.png`: design preview.

## Design

A compact, stylized desk lamp with a pleated linen shade, teal ceramic foot, walnut plinth, brass stem and trim, and a warm bulb. The pleats are modeled into the shade silhouette rather than painted on, so the folds read in the light.

## Workflow and asset notes

- Separate mesh objects are named by component and assigned material groups.
- The source mesh contains approximately 1,340 polygon faces (2,376 triangles after triangulation).
- The optional Blender builder performs a Smart UV Project unwrap and adds procedural bump detail to the linen and wood materials.
- The included mesh is a starting study. Review and edit it in Blender, then add your own variations and captures before presenting it as your portfolio work.

## Use

1. Import `stylized_desk_lamp.obj` in Blender. Keep the `.mtl` file in the same folder so the color materials load.
2. For the complete scene, open a new empty Blender file, open `build_in_blender.py` in the Scripting workspace, and click **Run Script**.
3. The script writes `stylized_desk_lamp.blend` and `stylized_desk_lamp_render.png` beside the OBJ.
