from pathlib import Path
import bpy
from mathutils import Vector

ASSET_DIR = Path(r"C:\Users\AJAR VASUPRADA\Documents\Codex\2026-10-19\ch\outputs\blender_portfolio\stylized_desk_lamp")
OBJ_PATH = ASSET_DIR / "stylized_desk_lamp.obj"
BLEND_PATH = ASSET_DIR / "stylized_desk_lamp.blend"
RENDER_PATH = ASSET_DIR / "stylized_desk_lamp_render.png"

# Run this in a new, empty Blender file. It imports the included OBJ geometry,
# creates editable UVs and materials, builds a simple studio setup, then saves.
for obj in list(bpy.context.scene.objects):
    bpy.data.objects.remove(obj, do_unlink=True)

verts = []
groups = []
current_obj = None
current_material = None
with OBJ_PATH.open("r", encoding="utf-8") as source:
    for raw in source:
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("mtllib"):
            continue
        parts = line.split()
        if parts[0] == "v":
            verts.append(tuple(float(v) for v in parts[1:4]))
        elif parts[0] == "o":
            current_obj = parts[1]
            groups.append({"name": current_obj, "material": None, "faces": []})
        elif parts[0] == "usemtl":
            current_material = parts[1]
            if groups:
                groups[-1]["material"] = current_material
        elif parts[0] == "f" and groups:
            ids = [int(v.split("/")[0]) - 1 for v in parts[1:]]
            groups[-1]["faces"].append(ids)

mat_colors = {
    "Oak_Wood": ((0.34, 0.16, 0.085, 1), 0.48, 0.0),
    "Teal_Ceramic": ((0.085, 0.39, 0.37, 1), 0.23, 0.0),
    "Brass": ((0.78, 0.48, 0.16, 1), 0.25, 0.72),
    "Linen_Cream": ((0.91, 0.76, 0.54, 1), 0.86, 0.0),
    "Warm_Emitter": ((1.0, 0.62, 0.25, 1), 0.32, 0.0),
}

def material(name):
    color, roughness, metallic = mat_colors[name]
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = color
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    shader = nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = color
    shader.inputs["Roughness"].default_value = roughness
    shader.inputs["Metallic"].default_value = metallic
    if name == "Warm_Emitter":
        emission_input = shader.inputs.get("Emission Color") or shader.inputs.get("Emission")
        if emission_input:
            emission_input.default_value = (1.0, 0.40, 0.12, 1)
        strength_input = shader.inputs.get("Emission Strength")
        if strength_input:
            strength_input.default_value = 1.8
    if name == "Linen_Cream":
        tex = nodes.new("ShaderNodeTexWave")
        tex.wave_type = "BANDS"
        tex.inputs["Scale"].default_value = 175
        tex.inputs["Distortion"].default_value = 2.0
        bump = nodes.new("ShaderNodeBump")
        bump.inputs["Strength"].default_value = 0.11
        bump.inputs["Distance"].default_value = 0.008
        links.new(tex.outputs["Color"], bump.inputs["Height"])
        links.new(bump.outputs["Normal"], shader.inputs["Normal"])
    elif name == "Oak_Wood":
        tex = nodes.new("ShaderNodeTexNoise")
        tex.inputs["Scale"].default_value = 8
        tex.inputs["Detail"].default_value = 3
        bump = nodes.new("ShaderNodeBump")
        bump.inputs["Strength"].default_value = 0.10
        bump.inputs["Distance"].default_value = 0.025
        links.new(tex.outputs["Fac"], bump.inputs["Height"])
        links.new(bump.outputs["Normal"], shader.inputs["Normal"])
    elif name == "Teal_Ceramic":
        coat = shader.inputs.get("Coat Weight")
        if coat:
            coat.default_value = 0.24
    return mat

materials = {name: material(name) for name in mat_colors}
for group in groups:
    used = sorted({i for face in group["faces"] for i in face})
    remap = {old: new for new, old in enumerate(used)}
    local_verts = [verts[i] for i in used]
    local_faces = [[remap[i] for i in face] for face in group["faces"]]
    mesh = bpy.data.meshes.new(group["name"] + "_Mesh")
    mesh.from_pydata(local_verts, [], local_faces)
    mesh.validate()
    mesh.update()
    obj = bpy.data.objects.new(group["name"], mesh)
    bpy.context.collection.objects.link(obj)
    mat = materials[group["material"]]
    mesh.materials.append(mat)
    for polygon in mesh.polygons:
        polygon.material_index = 0
        polygon.use_smooth = False
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    try:
        bpy.ops.uv.smart_project(island_margin=0.025)
    except Exception:
        pass
    bpy.ops.object.mode_set(mode="OBJECT")

def set_principled(obj, color, roughness=0.8, metallic=0.0):
    mat = bpy.data.materials.new(obj.name + "_Material")
    mat.diffuse_color = color
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = color
    shader.inputs["Roughness"].default_value = roughness
    shader.inputs["Metallic"].default_value = metallic
    obj.data.materials.append(mat)
    return obj

# Large matte ground for a seamless product-render background.
bpy.ops.mesh.primitive_plane_add(size=200, location=(0, 0, 0.0))
ground = bpy.context.object
ground.name = "STUDIO_Backdrop"
set_principled(ground, (0.72, 0.66, 0.55, 1), 0.92)

world = bpy.context.scene.world
world.color = (0.55, 0.48, 0.38)
world.use_nodes = True
world.node_tree.nodes["Background"].inputs["Color"].default_value = (0.55, 0.48, 0.38, 1)
world.node_tree.nodes["Background"].inputs["Strength"].default_value = 0.45

def area_light(name, location, energy, size, color):
    data = bpy.data.lights.new(name, "AREA")
    data.energy = energy
    data.shape = "DISK"
    data.size = size
    data.color = color
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    obj.rotation_euler = (Vector((0, 0, 1.6)) - obj.location).to_track_quat("-Z", "Y").to_euler()
    return obj

area_light("STUDIO_Key", (4, -4, 5.6), 520, 4.2, (1.0, 0.82, 0.62))
area_light("STUDIO_Fill", (-4, -2, 3.2), 240, 3.8, (0.68, 0.82, 1.0))
area_light("STUDIO_Rim", (1.5, 3.0, 4.7), 360, 3.2, (1.0, 0.74, 0.45))

light_data = bpy.data.lights.new("LAMP_Warm_Glow", "POINT")
light_data.energy = 24
light_data.color = (1.0, 0.45, 0.16)
light_data.shadow_soft_size = 0.32
light_obj = bpy.data.objects.new("LAMP_Warm_Glow", light_data)
bpy.context.collection.objects.link(light_obj)
light_obj.location = (0, 0, 2.38)

camera_data = bpy.data.cameras.new("STUDIO_Camera")
camera = bpy.data.objects.new("STUDIO_Camera", camera_data)
bpy.context.collection.objects.link(camera)
camera.location = (4.2, -6.8, 4.25)
target = Vector((0, 0, 1.65))
camera.rotation_euler = (target - camera.location).to_track_quat("-Z", "Y").to_euler()
camera_data.type = "ORTHO"
camera_data.ortho_scale = 5.2
bpy.context.scene.camera = camera

scene = bpy.context.scene
try:
    scene.render.engine = "BLENDER_EEVEE_NEXT"
except Exception:
    scene.render.engine = "BLENDER_EEVEE"
scene.render.resolution_x = 1200
scene.render.resolution_y = 1200
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = "PNG"
scene.render.film_transparent = False
scene.render.filepath = str(RENDER_PATH)
scene.render.image_settings.color_mode = "RGBA"
scene.render.resolution_percentage = 100
scene.render.filepath = str(RENDER_PATH)
scene.view_settings.view_transform = "AgX"
scene.camera.data.lens = 50
scene.render.filepath = str(RENDER_PATH)
scene.render.image_settings.color_depth = "8"
scene.render.filepath = str(RENDER_PATH)
scene.render.film_transparent = False
scene.camera.data.dof.use_dof = False
scene.render.resolution_percentage = 100
scene.render.filepath = str(RENDER_PATH)

bpy.ops.wm.save_as_mainfile(filepath=str(BLEND_PATH))
bpy.ops.render.render(write_still=True)
print(f"Saved Blender project: {BLEND_PATH}")
print(f"Saved render: {RENDER_PATH}")
